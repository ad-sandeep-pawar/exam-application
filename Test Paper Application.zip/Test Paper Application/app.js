const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");


const app = express();
const port = 3000;


app.use(cors());
// Middleware to parse JSON
app.use(bodyParser.json());

// Connect to MongoDB (adjust the connection string)
mongoose.connect("mongodb+srv://sandeep-testdb:algo-testdb@cluster0.gxh8swh.mongodb.net/?retryWrites=true&w=majority", {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Define a Question schema and model
const questionSchema = new mongoose.Schema({
    question: String,
    options: [
        {
            text: String,
            isCorrect: Boolean
        }
    ]
});

const Question = mongoose.model("Question", questionSchema);

// Define a Response schema and model
const responseSchema = new mongoose.Schema({
    questionId: mongoose.Schema.Types.ObjectId,
    answer: String
});

const Response = mongoose.model("Response", responseSchema);

// Define the schema
const securityCodeSchema = new mongoose.Schema({
    code: {
        type: Number,
        required: true,
        unique: true,
    },
    isActive: {
        type: Boolean,
        required: true,
    },
});

// Create the model
const SecurityCode = mongoose.model('SecurityCode', securityCodeSchema);

// Define a new route for adding questions
app.post("/add-question", async (req, res) => {
    const { question, options } = req.body;

    try {
        // Create a new Question document in your MongoDB database
        const newQuestion = new Question({
            question,
            options
        });

        await newQuestion.save();
        res.status(201).json({ message: "Question added successfully!" });
    } catch (error) {
        console.error("Error adding question:", error);
        res.status(500).json({ error: "Failed to add question" });
    }
});

// Sample route to fetch a random question
app.get("/all-questions", async (req, res) => {
    try {
        // Fetch all questions from your database (assuming you have a Question model)
        const allQuestions = await Question.find();

        if (!allQuestions || allQuestions.length === 0) {
            return res.status(404).json({ error: "No questions available" });
        }

        res.json(allQuestions);
    } catch (error) {
        console.error("Error fetching questions:", error);
        res.status(500).json({ error: "Failed to fetch questions" });
    }
});


// Route to submit a response
app.post("/submit", async (req, res) => {
    const { questionId, answer } = req.body;
    try {
        const response = new Response({
            questionId,
            answer
        });
        await response.save();
        res.status(200).json({ message: "Response saved successfully!" });
    } catch (error) {
        console.error("Error saving response:", error);
        res.status(500).json({ error: "Failed to save response" });
    }
});

app.post("/add-security-code", async (req, res) => {
    const { code, isActive } = req.body;

    try {
        // Create a new security code document
        const newSecurityCode = new SecurityCode({
            code,
            isActive,
        });

        // Save the new security code to the database
        await newSecurityCode.save();

        res.status(201).json({ message: "Security code added successfully" });
    } catch (error) {
        console.error("Error adding security code:", error);
        res.status(500).json({ error: "Failed to add security code" });
    }
});

app.post("/verify-security-code", async (req, res) => {
    const { securityCode } = req.body;


    try {
        const foundSecurityCode = await SecurityCode.findOne({ code: securityCode });


        if (foundSecurityCode && foundSecurityCode.isActive) {
            // Security code is valid and active
            res.json({ status: "active" });
        } else {
            // Security code is either invalid or inactive
            res.json({ status: "inactive" });
        }
    } catch (error) {
        console.error("Error verifying security code:", error);
        res.status(500).json({ status: "inactive" });
    }
});










app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

