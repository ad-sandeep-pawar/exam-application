const startTestForm = document.getElementById("start-test-form");

startTestForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const securityCode = document.getElementById("security-code").value;

    // Send security code to the backend for verification
    const response = await fetch("http://localhost:3000/verify-security-code", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ securityCode }),
    });

    if (response.ok) {
        const data = await response.json();
        console.log(data)
        if (data.status === "active") {
            // Security code is valid and active, navigate to the test page
            sessionStorage.setItem("examStarted", "true");
            // When starting the exam
            const startTime = new Date().getTime(); // Get the current timestamp


            window.location.href = "index.html"; // Replace with your test page URL
        } else {
            // Security code is invalid or inactive, show an error message
            alert("Invalid or inactive security code. Please try again.");
        }
    } else {
        // Handle network error or server error
        alert("Error verifying security code. Please try again later.");
    }
});
