const questionText = document.getElementById("question-text");
const questionNumber = document.getElementById("question-number");
const questionForm = document.getElementById("question-form");
const nextButton = document.getElementById("next-button");
const timerDisplay = document.getElementById("timer-display");

let currentQuestionIndex = 0; // Initialize the question index
let questions = []; // Array to store all fetched questions

// Function to fetch all questions from the backend
async function fetchAllQuestions() {
    try {
        const response = await fetch("http://localhost:3000/all-questions"); // Adjust the URL to match your backend route
        console.log("Response status:", response.status);

        if (!response.ok) {
            throw new Error("Failed to fetch questions");
        }

        questions = await response.json();
        console.log("Fetched questions:", questions);

        if (questions.length === 0) {
            // No questions available
            alert("No questions available.");
            nextButton.disabled = true; // Disable the nextButton
        } else {
            // Start displaying questions
            fetchNextQuestion();
        }
    } catch (error) {
        console.error("Error fetching questions:", error);
        alert("Failed to fetch questions. Please try again later.");
    }
}

// Function to fetch and display the next question
function fetchNextQuestion() {
    if (currentQuestionIndex >= questions.length) {
        // All questions have been attempted
        alert("You have attempted all questions.");
        nextButton.disabled = true; // Disable the nextButton
        redirectToThankYouPage();
        return;
    }

    const question = questions[currentQuestionIndex];
    var questionId = question._id;
    console.log(questionId);
    currentQuestionIndex++; // Increment the question index

    updateQuestionUI(question, currentQuestionIndex, questionId);
}

// Function to update the UI with the fetched question
function updateQuestionUI(question, questionNumber, questionId) {
    questionText.textContent = question.question;
    questionNumber.textContent = `Question ${questionNumber}`; // Display the question number

    // Clear previous options
    questionForm.innerHTML = "";

    // Add new options
    question.options.forEach((option, index) => {
        const label = document.createElement("label");
        const isCorrect = question.options[index].isCorrect;
        label.innerHTML = `
            <input type="radio" name="answer" value="${isCorrect}"> ${option.text}
        `;
        questionForm.appendChild(label);
    });

    // Store the current questionId in a data attribute
    questionForm.setAttribute("data-question-id", questionId);
}

// Function to submit a response to the backend
async function submitResponse() {
    const selectedOption = questionForm.querySelector("input[name='answer']:checked");
    if (!selectedOption) {
        alert("Please select an answer.");
        return;
    }

    const answerIndex = selectedOption.value;
    // const answerIndex = parseInt(selectedOption.value);
    const questionId = questionForm.getAttribute("data-question-id"); // Get the questionId from data attribute

    try {
        const response = await fetch("http://localhost:3000/submit", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ questionId, answer: answerIndex }) // Include questionId when submitting the response
        });

        console.log("Response status:", response.status);

        if (!response.ok) {
            throw new Error("Failed to submit response");
        }

        // Fetch and display the next question after submitting the response
        fetchNextQuestion();
    } catch (error) {
        console.error("Error submitting response:", error);
        alert("Failed to submit response. Please try again later.");
    }
}
// Timer function with optional remaining time as parameter
function startTimer(remainingTime = 30 * 60 * 1000) {
    let timeRemaining = remainingTime;
    let timerInterval;

    function updateTimerDisplay() {
        const minutes = Math.floor(timeRemaining / 60 / 1000);
        const seconds = Math.floor((timeRemaining % (60 * 1000)) / 1000);

        const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        timerDisplay.textContent = formattedTime;

        if (timeRemaining <= 0) {
            clearInterval(timerInterval);
            alert("Time has ended. You cannot answer more questions.");
            // Disable the nextButton
            nextButton.disabled = true;
            redirectToThankYouPage();
        }

        timeRemaining -= 1000; // Decrease by 1 second
    }

    updateTimerDisplay(); // Initialize the timer display

    timerInterval = setInterval(updateTimerDisplay, 1000); // Update every 1 second

    // Store the exam start time in local storage only if it's not already stored
    if (!localStorage.getItem("examStartTime")) {
        const examStartTime = new Date().getTime();
        localStorage.setItem("examStartTime", examStartTime.toString());
    }
}

// On page load
const examStartTime = localStorage.getItem("examStartTime");

if (examStartTime) {
    // Calculate the remaining time based on the stored start time and the exam duration
    const currentTime = new Date().getTime();
    const durationInMilliseconds = 30 * 60 * 1000; // 30 minutes in milliseconds
    const elapsed = currentTime - parseInt(examStartTime, 10);

    // Calculate the remaining time by subtracting elapsed time from the total duration
    const remainingTime = Math.max(durationInMilliseconds - elapsed, 0);

    // Start the timer with the remaining time
    startTimer(remainingTime);
} else {
    // The exam has not started yet, you can start the timer from the beginning
    startTimer(30 * 60 * 1000); // 30 minutes
}



function redirectToThankYouPage() {
    // Redirect to the thank-you page
    window.location.href = "thank-you.html";

    // Clear the browser's history
    window.history.pushState({}, "", "thank-you.html");
    window.history.pushState({}, "", "thank-you.html");
    window.onpopstate = function (event) {
        // Prevent going back to the previous page
        window.history.forward();
    };
}


// Check if the exam has started
if (!sessionStorage.getItem("examStarted")) {
    // Exam has not started, redirect to the security code entry page
    window.location.href = "login.html"; // Replace with your security code entry page URL
}

// Disable the browser's back button
history.pushState(null, null, location.href);
window.onpopstate = function () {
    history.go(1);
};








// Event listeners
nextButton.addEventListener("click", submitResponse);

// Initial fetch of all questions
fetchAllQuestions();

// Start the timer when the page loads
startTimer();
